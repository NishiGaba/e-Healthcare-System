function sign()
{
	window.location="signup.php";
}