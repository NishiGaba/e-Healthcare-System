<?php 
	$db=mysql_connect("localhost","root","") or die(mysql_error());
	$db_sel=mysql_select_db("health")or die(mysql_error());
?>