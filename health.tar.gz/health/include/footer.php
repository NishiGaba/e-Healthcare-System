<!-- ############   E-Health_Care_Footer   ############ -->
<div class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 text-center">
					&copy; 2016 <span style="font-family:monospace">e</span>Health Care Enterprise Ltd. </br>
						 All Rights Reserved.</br></br>
			</div>
		</div>
	</div>
</div>